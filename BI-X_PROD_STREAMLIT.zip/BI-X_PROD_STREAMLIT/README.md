# BI-X — Production-oriented Streamlit application

This implementation wraps the supplied `pbip_reverse_engineer.py` as the Power BI
functional baseline and adds a modular application/service layer, BI-IR, Tableau
extraction, lineage, validation, comparison, AI-provider abstraction, workspace
handling, CLI, tests, and Streamlit UI.

## Run

```powershell
py -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

CLI:

```powershell
python cli.py --platform "Power BI" "C:\path\project.zip" -o workspace\pbi
python cli.py --platform Tableau "C:\path\workbook.twbx" -o workspace\tableau
```

## Architecture

`app.py` is UI only. Business logic lives in services and adapters.

```text
Streamlit
   |
   +-- ExtractionService
   +-- TranslationService
   +-- GenerationService
   +-- ComparisonService
   +-- LineageService
   +-- ValidationService
   |
   +-- BI-IR
        +-- Power BI adapter
        +-- Tableau adapter
        +-- AI provider abstraction
```

## Security

* ZIP extraction is path-traversal protected.
* Cached `.abf` files are skipped by the supplied Power BI baseline.
* Tableau XML rejects DOCTYPE/ENTITY declarations before parsing.
* API keys are session-only or environment-based and are not written to BI-IR.
* Do not expose the Streamlit service directly to the public internet; use enterprise authentication/reverse proxy.

## Capability boundary

Power BI reverse-engineering and rebuild behavior is based on the supplied reference
implementation. Tableau extraction is intentionally forensic/metadata oriented and
preserves the original TWB XML when available. A fully semantic Tableau generator
and a from-scratch Power BI generator require vendor-format-specific semantics that
should only be claimed after round-trip validation against real projects.

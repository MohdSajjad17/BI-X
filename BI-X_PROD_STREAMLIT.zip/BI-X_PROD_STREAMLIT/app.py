from __future__ import annotations
import json, os, tempfile, shutil
from pathlib import Path
import streamlit as st

from bix.services.extraction import ExtractionService
from bix.services.translation import TranslationService
from bix.services.generation import GenerationService
from bix.services.comparison import ComparisonService
from bix.services.lineage import LineageService
from bix.services.validation import ValidationService

st.set_page_config(page_title="BI-X", page_icon="◈", layout="wide", initial_sidebar_state="expanded")

def init_state():
    st.session_state.setdefault("result", None)
    st.session_state.setdefault("bi_ir", None)
    st.session_state.setdefault("history", [])
    st.session_state.setdefault("last_output", None)
    st.session_state.setdefault("workspace", str(Path("workspace").resolve()))
init_state()

def save_uploaded(uploaded, root):
    if uploaded is None: return None
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    p=root/uploaded.name
    p.write_bytes(uploaded.getbuffer())
    return p

def metric_row(items):
    cols=st.columns(len(items))
    for c,(label,value) in zip(cols,items):
        c.metric(label,value)

st.title("BI-X")
st.caption("Bidirectional BI metadata reverse-engineering, translation, generation, lineage and validation.")

tabs=st.tabs(["Extract & Analyze","AI Translator","Generate","Compare","Lineage","Validation","Settings"])

# ---------------- Extract ----------------
with tabs[0]:
    st.subheader("Extract & Analyze")
    platform=st.selectbox("Source Platform",["Power BI","Tableau"])
    input_mode=st.radio("Input",["Upload","Local path"],horizontal=True)
    source=None
    if input_mode=="Upload":
        types=["zip","pbip"] if platform=="Power BI" else ["twb","twbx"]
        uploaded=st.file_uploader("Project file",type=types)
        if uploaded:
            source=save_uploaded(uploaded,Path("workspace")/"uploads")
    else:
        source=st.text_input("Local file/folder path")
        source=Path(source) if source else None
    output=st.text_input("Output directory",value=str(Path("workspace")/"extraction"))
    c1,c2,c3=st.columns(3)
    with c1:
        preserve_raw=st.checkbox("Preserve raw metadata",True)
        run_validation=st.checkbox("Run validation",True)
    with c2:
        gen_xlsx=st.checkbox("Generate XLSX",True)
        gen_md=st.checkbox("Generate Markdown",True)
    with c3:
        gen_rebuild=st.checkbox("Generate rebuild artifact",True)
        full_culture=st.checkbox("Full culture metadata",False)

    if st.button("EXTRACT METADATA",type="primary",use_container_width=True):
        if not source or not Path(source).exists():
            st.error("Select a valid input file/folder.")
        else:
            bar=st.progress(0)
            status=st.empty()
            steps=[]
            def progress(msg):
                steps.append(msg); status.write(" → ".join(steps[-4:]))
                bar.progress(min(95,20+len(steps)*12))
            try:
                result=ExtractionService().extract(platform,source,output,include_raw=preserve_raw,
                    full_culture=full_culture,generate_xlsx=gen_xlsx,generate_markdown=gen_md,
                    generate_rebuild=gen_rebuild,progress=progress)
                ir=result["bi_ir"]
                lineage=LineageService().build(ir)
                ir["lineage"]=lineage
                if run_validation:
                    ir["validation"]=ValidationService().validate_bi_ir(ir)
                Path(output,"bi-ir.json").write_text(json.dumps(ir,indent=2,ensure_ascii=False,default=str),encoding="utf-8")
                st.session_state.result=result
                st.session_state.bi_ir=ir
                st.session_state.last_output=output
                bar.progress(100); status.success("Extraction completed.")
            except Exception as e:
                st.exception(e)

    if st.session_state.bi_ir:
        ir=st.session_state.bi_ir
        sm=ir.get("semantic_model") or {}
        rep=ir.get("report") or {}
        metric_row([("Platform",ir.get("source",{}).get("platform","-")),
                    ("Tables",len(sm.get("tables",[]))),("Relationships",len(sm.get("relationships",[]))),
                    ("Pages",len(rep.get("pages",[]))),("Visuals",len(rep.get("visuals",[])))])
        st.divider()
        st.subheader("Metadata Explorer")
        categories=["Project","Tables","Columns","Measures","Relationships","Expressions","Pages","Visuals","Filters","Validation","Lineage","Raw BI-IR"]
        cat=st.selectbox("Object category",categories)
        q=st.text_input("Search",placeholder="Name, table, expression...")
        if cat=="Raw BI-IR":
            st.json(ir)
        elif cat=="Project":
            st.json(ir.get("project"))
        elif cat=="Tables":
            rows=[{"name":t.get("name"),"columns":len(t.get("columns",[])),"measures":len(t.get("measures",[])),"hidden":t.get("hidden")} for t in sm.get("tables",[])]
            st.dataframe([r for r in rows if not q or q.lower() in str(r).lower()],use_container_width=True)
        elif cat=="Columns":
            rows=[{"table":t.get("name"),"column":c.get("name"),"dataType":c.get("dataType"),"type":c.get("type"),"hidden":c.get("hidden"),"expression":c.get("expression")} for t in sm.get("tables",[]) for c in t.get("columns",[])]
            st.dataframe([r for r in rows if not q or q.lower() in str(r).lower()],use_container_width=True)
        elif cat=="Measures":
            rows=[{"table":t.get("name"),"measure":m.get("name"),"expression":m.get("expression"),"format":m.get("formatString"),"hidden":m.get("hidden")} for t in sm.get("tables",[]) for m in t.get("measures",[])]
            st.dataframe([r for r in rows if not q or q.lower() in str(r).lower()],use_container_width=True)
        elif cat=="Relationships":
            st.dataframe(sm.get("relationships",[]),use_container_width=True)
        elif cat=="Expressions":
            st.dataframe(sm.get("expressions",[]),use_container_width=True)
        elif cat=="Pages":
            st.dataframe(rep.get("pages",[]) or rep.get("worksheets",[]),use_container_width=True)
        elif cat=="Visuals":
            st.dataframe(rep.get("visuals",[]) or rep.get("dashboards",[]),use_container_width=True)
        elif cat=="Filters":
            st.dataframe(rep.get("filters",[]),use_container_width=True)
        elif cat=="Validation":
            st.dataframe(ir.get("validation",[]),use_container_width=True)
        elif cat=="Lineage":
            st.dataframe(ir.get("lineage",{}).get("nodes",[]),use_container_width=True)
    if st.session_state.last_output:
        st.info(f"Artifacts: {Path(st.session_state.last_output).resolve()}")

# ---------------- AI Translator ----------------
with tabs[1]:
    st.subheader("AI Calculation Translator")
    mode=st.radio("Mode",["Manual","Metadata-driven"],horizontal=True)
    source_lang=st.selectbox("Source language",["TABLEAU_CALC","DAX","M"])
    target_lang=st.selectbox("Target language",["DAX","TABLEAU_CALC","M"])
    provider=st.selectbox("AI Provider",["OpenAI","Anthropic"])
    model=st.text_input("Model",value=os.getenv("OPENAI_MODEL","gpt-5"))
    api_key=st.text_input("API key (session only)",type="password",help="Never stored in BI-IR, artifacts, logs, or Git.")
    expr=""
    context={}
    if mode=="Manual":
        expr=st.text_area("Calculation",height=180)
    else:
        ir=st.session_state.bi_ir
        options=[]
        if ir:
            for t in (ir.get("semantic_model") or {}).get("tables",[]):
                for m in t.get("measures",[]):
                    options.append((f"{t.get('name')} / {m.get('name')}",m))
                for c in t.get("columns",[]):
                    if c.get("expression"): options.append((f"{t.get('name')} / {c.get('name')}",c))
        selected=st.selectbox("Extracted calculation",["-- Select --"]+[x[0] for x in options])
        if selected!="-- Select --":
            obj=dict(options[[x[0] for x in options].index(selected)][1])
            expr=obj.get("expression",""); context={"selected_object":selected,"object":obj}
            st.code(expr,language="text")
    if st.button("CONVERT",type="primary"):
        if not expr.strip(): st.warning("Provide or select a calculation.")
        elif not api_key and not os.getenv({"OpenAI":"OPENAI_API_KEY","Anthropic":"ANTHROPIC_API_KEY"}[provider]):
            st.error("Provide an API key or configure the provider environment variable.")
        else:
            try:
                result=TranslationService().translate(provider,model,source_lang,target_lang,expr,context,api_key=api_key)
                st.session_state.history.append(result)
                st.success(result["status"])
                c1,c2=st.columns(2)
                c1.subheader("Original"); c1.code(result["source_expression"])
                c2.subheader("Target"); c2.code(result["target_expression"])
                st.json({k:result[k] for k in ["status","confidence","warnings","dependencies","semantic_notes","manual_review_required"]})
            except Exception as e: st.exception(e)
    if st.session_state.history:
        st.subheader("Translation history")
        st.dataframe(st.session_state.history,use_container_width=True)

# ---------------- Generate ----------------
with tabs[2]:
    st.subheader("Generate")
    target=st.selectbox("Target",["Power BI","Tableau"])
    mode=st.selectbox("Mode",["Strict","Best Effort","Dry Run"])
    use_approved=st.checkbox("Use approved AI translations",True)
    gen_out=st.text_input("Generation output",value=str(Path("workspace")/"generated"))
    if st.button("GENERATE",type="primary"):
        if not st.session_state.bi_ir:
            st.warning("Extract a project first or load a BI-IR.")
        else:
            try:
                result=GenerationService().generate(st.session_state.bi_ir,target,gen_out,mode)
                st.json(result)
                st.success("Generation workflow completed with the reported capability/limitations.")
            except Exception as e: st.exception(e)

# ---------------- Compare ----------------
with tabs[3]:
    st.subheader("Compare BI-IR")
    left_file=st.file_uploader("Original BI-IR",type=["json"],key="cmp_left")
    right_file=st.file_uploader("Generated BI-IR",type=["json"],key="cmp_right")
    if st.button("COMPARE",type="primary"):
        if not left_file or not right_file: st.warning("Upload both BI-IR JSON files.")
        else:
            try:
                a=json.load(left_file); b=json.load(right_file)
                result=ComparisonService().compare(a,b)
                metric_row([(k,v) for k,v in result["summary"].items()])
                st.dataframe(result["items"],use_container_width=True)
            except Exception as e: st.exception(e)

# ---------------- Lineage ----------------
with tabs[4]:
    st.subheader("Lineage")
    if st.session_state.bi_ir:
        lin=st.session_state.bi_ir.get("lineage") or LineageService().build(st.session_state.bi_ir)
        ids=[n["id"] for n in lin.get("nodes",[])]
        selected=st.selectbox("Object",ids or ["No nodes"])
        if ids:
            upstream=[e for e in lin["edges"] if e["target"]==selected]
            downstream=[e for e in lin["edges"] if e["source"]==selected]
            c1,c2=st.columns(2)
            c1.write("Upstream"); c1.dataframe(upstream,use_container_width=True)
            c2.write("Downstream"); c2.dataframe(downstream,use_container_width=True)
        st.download_button("Download lineage.json",json.dumps(lin,indent=2),file_name="lineage.json")
    else:
        st.info("Extract a project first.")

# ---------------- Validation ----------------
with tabs[5]:
    st.subheader("Validation")
    if st.session_state.bi_ir:
        issues=ValidationService().validate_bi_ir(st.session_state.bi_ir)
        metric_row([("PASS",sum(x["status"]=="PASS" for x in issues)),
                    ("WARN",sum(x["status"]=="WARN" for x in issues)),
                    ("FAIL",sum(x["status"]=="FAIL" for x in issues))])
        st.dataframe(issues,use_container_width=True)
    else:
        st.info("Extract a project first.")

# ---------------- Settings ----------------
with tabs[6]:
    st.subheader("Settings")
    st.write("Configuration is session-first. API secrets are never written to BI-IR or generated artifacts.")
    st.text_input("Default workspace",value=st.session_state.workspace,disabled=True)
    st.write("Environment variables supported: OPENAI_API_KEY, OPENAI_BASE_URL, OPENAI_MODEL, ANTHROPIC_API_KEY, ANTHROPIC_API_URL.")
    st.write("For enterprise deployment, place this app behind your organization's authentication/reverse proxy and use a restricted writable workspace.")

from pathlib import Path
import tempfile, zipfile
from bix.adapters.powerbi.reference import _safe_extract
def test_zip_slip_blocked():
    with tempfile.TemporaryDirectory() as td:
        z=Path(td)/"x.zip"
        with zipfile.ZipFile(z,"w") as f: f.writestr("../evil.txt","bad")
        with zipfile.ZipFile(z) as f:
            try:
                _safe_extract(f,Path(td)/"out",[])
            except ValueError:
                return
        raise AssertionError("zip-slip was not blocked")

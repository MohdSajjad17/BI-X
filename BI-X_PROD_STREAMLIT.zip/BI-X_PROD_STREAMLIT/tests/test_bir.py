from bix.core.bir import stable_id, normalize_powerbi
def test_stable_id_is_deterministic():
    assert stable_id("a","b")==stable_id("a","b")
    assert stable_id("a","b")!=stable_id("b","a")
def test_powerbi_normalization():
    x=normalize_powerbi({"project":{"name":"X","pbip":"X.pbip"},"validation":[]})
    assert x.source["platform"]=="Power BI"
    assert x.project["identity"]["name"]=="X"

from __future__ import annotations
import argparse, json
from bix.services.extraction import ExtractionService

def main():
    ap=argparse.ArgumentParser(description="BI-X deterministic metadata extraction CLI")
    ap.add_argument("input", help="Power BI ZIP/PBIP/folder or Tableau TWB/TWBX/folder")
    ap.add_argument("-p","--platform",choices=["Power BI","Tableau"],required=True)
    ap.add_argument("-o","--output",default="workspace/cli_output")
    ap.add_argument("--no-raw",action="store_true")
    ap.add_argument("--no-xlsx",action="store_true")
    ap.add_argument("--no-markdown",action="store_true")
    ap.add_argument("--no-rebuild",action="store_true")
    args=ap.parse_args()
    result=ExtractionService().extract(args.platform,args.input,args.output,include_raw=not args.no_raw,
        generate_xlsx=not args.no_xlsx,generate_markdown=not args.no_markdown,generate_rebuild=not args.no_rebuild)
    print(json.dumps({"output_dir":result["output_dir"],"source":result["bi_ir"]["source"]},indent=2))
    return 0
if __name__=="__main__":
    raise SystemExit(main())

from __future__ import annotations
    import json, os, urllib.request, urllib.error, uuid
    from dataclasses import dataclass
    from datetime import datetime, timezone

    @dataclass
    class TranslationResult:
        translation_id: str
        source_language: str
        target_language: str
        source_expression: str
        target_expression: str
        status: str
        confidence: str
        dependencies: list
        warnings: list
        semantic_notes: list
        manual_review_required: bool
        provider: str
        model: str
        timestamp: str
        raw: dict | None = None
        def to_dict(self): return self.__dict__.copy()

    class AIProvider:
        name="base"
        def translate(self, *, source_language, target_language, expression, context, model, temperature=0.0, max_tokens=2000, timeout=60):
            raise NotImplementedError

    def _post_json(url, headers, payload, timeout):
        req=urllib.request.Request(url, data=json.dumps(payload).encode(), headers={**headers,"Content-Type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())

    class OpenAIProvider(AIProvider):
        name="OpenAI"
        def __init__(self,key,endpoint="https://api.openai.com/v1"):
            self.key=key; self.endpoint=endpoint.rstrip("/")
        def translate(self, **kw):
            prompt=f"""Translate a BI calculation safely.
Source language: {kw['source_language']}
Target language: {kw['target_language']}
Expression:
{kw['expression']}
Context:
{json.dumps(kw.get('context') or {},ensure_ascii=False)}
Return JSON only with target_expression,status,confidence,dependencies,warnings,semantic_notes,manual_review_required."""
            data=_post_json(self.endpoint+"/chat/completions",{"Authorization":f"Bearer {self.key}"},{"model":kw["model"],"temperature":kw.get("temperature",0),"max_tokens":kw.get("max_tokens",2000),"messages":[{"role":"system","content":"You are a BI calculation translation engine. Never modify source files."},{"role":"user","content":prompt}]},kw.get("timeout",60))
            content=data["choices"][0]["message"]["content"]
            try: obj=json.loads(content)
            except Exception: obj={"target_expression":content,"status":"manual_review","confidence":"low","dependencies":[],"warnings":["Provider returned non-JSON output"],"semantic_notes":[],"manual_review_required":True}
            return TranslationResult(uuid.uuid4().hex,kw["source_language"],kw["target_language"],kw["expression"],obj.get("target_expression",""),obj.get("status","manual_review"),obj.get("confidence","low"),obj.get("dependencies",[]),obj.get("warnings",[]),obj.get("semantic_notes",[]),bool(obj.get("manual_review_required",True)),self.name,kw["model"],datetime.now(timezone.utc).isoformat(),data)

    class AnthropicProvider(AIProvider):
        name="Anthropic"
        def __init__(self,key,endpoint="https://api.anthropic.com/v1/messages"):
            self.key=key; self.endpoint=endpoint
        def translate(self, **kw):
            prompt=f"""Translate from {kw['source_language']} to {kw['target_language']}.
Expression:
{kw['expression']}
Context:
{json.dumps(kw.get('context') or {},ensure_ascii=False)}
Return JSON only: target_expression,status,confidence,dependencies,warnings,semantic_notes,manual_review_required."""
            data=_post_json(self.endpoint,{"x-api-key":self.key,"anthropic-version":"2023-06-01"},{"model":kw["model"],"max_tokens":kw.get("max_tokens",2000),"temperature":kw.get("temperature",0),"messages":[{"role":"user","content":prompt}]},kw.get("timeout",60))
            content="".join(x.get("text","") for x in data.get("content",[]) if x.get("type")=="text")
            try: obj=json.loads(content)
            except Exception: obj={"target_expression":content,"status":"manual_review","confidence":"low","dependencies":[],"warnings":["Provider returned non-JSON output"],"semantic_notes":[],"manual_review_required":True}
            return TranslationResult(uuid.uuid4().hex,kw["source_language"],kw["target_language"],kw["expression"],obj.get("target_expression",""),obj.get("status","manual_review"),obj.get("confidence","low"),obj.get("dependencies",[]),obj.get("warnings",[]),obj.get("semantic_notes",[]),bool(obj.get("manual_review_required",True)),self.name,kw["model"],datetime.now(timezone.utc).isoformat(),data)

    def provider_from_env(provider, key=None, endpoint=None):
        key = key or os.getenv({"OpenAI":"OPENAI_API_KEY","Anthropic":"ANTHROPIC_API_KEY"}.get(provider,""))
        if not key: raise ValueError("API key is required. Provide it in session-only configuration or the corresponding environment variable.")
        if provider=="OpenAI": return OpenAIProvider(key, endpoint or os.getenv("OPENAI_BASE_URL","https://api.openai.com/v1"))
        if provider=="Anthropic": return AnthropicProvider(key, endpoint or os.getenv("ANTHROPIC_API_URL","https://api.anthropic.com/v1/messages"))
        raise ValueError(f"Unsupported provider: {provider}")

from __future__ import annotations
import copy, hashlib, json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "1.0"

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def stable_id(*parts: Any) -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]

@dataclass
class BIIR:
    project: dict[str, Any]
    source: dict[str, Any]
    semantic_model: dict[str, Any] | None = None
    report: dict[str, Any] | None = None
    data_sources: list[dict[str, Any]] = field(default_factory=list)
    lineage: dict[str, Any] = field(default_factory=dict)
    validation: list[dict[str, Any]] = field(default_factory=list)
    extensions: dict[str, Any] = field(default_factory=dict)
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "BI-X BI-IR",
            "schema_version": SCHEMA_VERSION,
            "version": self.version,
            "generated_at": utc_now(),
            "project": self.project,
            "source": self.source,
            "semantic_model": self.semantic_model,
            "report": self.report,
            "data_sources": self.data_sources,
            "lineage": self.lineage,
            "validation": self.validation,
            "extensions": self.extensions,
        }

    def clone(self) -> "BIIR":
        return BIIR(**copy.deepcopy(self.__dict__))

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False, default=str), encoding="utf-8")

def normalize_powerbi(meta: dict[str, Any]) -> BIIR:
    project = meta.get("project", {})
    src = {
        "platform": "Power BI",
        "format": ((project.get("pbip") or "").split(".")[-1].upper() or "PBIP"),
        "name": project.get("name"),
        "input": meta.get("input"),
    }
    return BIIR(
        project={"identity": {"name": project.get("name"), "platform": "Power BI"},
                 "metadata": {"pbip": project.get("pbipContent"),
                              "reportFolder": project.get("reportFolder"),
                              "modelFolder": project.get("modelFolder"),
                              "datasetReference": project.get("datasetReference")}},
        source=src,
        semantic_model=meta.get("semanticModel"),
        report=meta.get("report"),
        validation=meta.get("validation", []),
        extensions={"powerbi": {
            "powerQuery": meta.get("powerQuery", []),
            "parameters": meta.get("parameters", []),
            "skippedCacheFiles": meta.get("skippedCacheFiles", []),
        }},
    )

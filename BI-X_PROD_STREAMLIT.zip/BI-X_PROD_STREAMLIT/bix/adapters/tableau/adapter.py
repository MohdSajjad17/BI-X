from __future__ import annotations
import copy, hashlib, json, re, shutil, tempfile, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from ..powerbi.reference import _safe_extract

def _tag(e): return e.tag.rsplit("}", 1)[-1]

def _attrs(e):
    return {k.rsplit("}", 1)[-1]: v for k, v in e.attrib.items()}

def _text(e):
    return "".join(e.itertext()).strip() if e is not None else ""

def _safe_xml(path: Path):
    # ElementTree does not resolve external entities by default; additionally
    # reject DOCTYPE/entity declarations before parsing for defense in depth.
    raw = path.read_bytes()
    if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise ValueError(f"External XML declarations are not allowed: {path.name}")
    return ET.fromstring(raw)

def _field_from_column(c):
    a = _attrs(c)
    name = a.get("name") or a.get("caption") or _text(c)
    return {
        "name": name,
        "caption": a.get("caption"),
        "datatype": a.get("datatype"),
        "role": a.get("role"),
        "type": a.get("type"),
        "hidden": str(a.get("hidden", "")).lower() == "true",
        "formula": a.get("formula") or next((_text(x) for x in c if _tag(x) == "calculation"), None),
        "aggregation": a.get("aggregation"),
        "semanticRole": a.get("semantic-role"),
    }

def extract_twb(path: Path) -> dict:
    root = _safe_xml(path)
    work = {"name": path.stem, "file": str(path), "worksheets": [], "dashboards": [],
            "stories": [], "datasources": [], "fields": [], "calculations": [],
            "parameters": [], "filters": [], "actions": [], "extensions": {}}

    for e in root.iter():
        t = _tag(e); a = _attrs(e)
        if t == "datasource":
            work["datasources"].append({"name": a.get("name"), "caption": a.get("caption"),
                                        "inline": a.get("inline"), "hasExtract": any(_tag(x) == "extract" for x in e.iter())})
        elif t == "worksheet":
            work["worksheets"].append({"name": a.get("name"), "caption": a.get("caption"),
                                       "style": a.get("style")})
        elif t == "dashboard":
            work["dashboards"].append({"name": a.get("name"), "caption": a.get("caption")})
        elif t == "story":
            work["stories"].append({"name": a.get("name"), "caption": a.get("caption")})
        elif t == "column":
            f = _field_from_column(e)
            work["fields"].append(f)
            if f.get("formula"):
                work["calculations"].append({"name": f["name"], "expression": f["formula"], "language": "TABLEAU_CALC"})
        elif t in {"column-instance", "groupfilter", "filter"}:
            work["filters"].append({"type": t, **a})
        elif t in {"parameter", "parameter-domain"}:
            work["parameters"].append({"type": t, **a})
        elif t in {"action", "dashboard-action", "worksheet-action"}:
            work["actions"].append({"type": t, **a})
    # Keep raw XML available for forensic reconstruction, but don't invent
    # unsupported semantic structures.
    work["extensions"]["tableau"] = {"rootTag": _tag(root), "rawXml": path.read_text(encoding="utf-8", errors="replace")}
    return work

def extract(path: str | Path) -> dict:
    p = Path(path)
    if p.is_dir():
        twbs = sorted(p.rglob("*.twb"))
        if not twbs:
            raise ValueError("No .twb file found in Tableau folder.")
        return extract_twb(twbs[0])
    if p.suffix.lower() == ".twb":
        return extract_twb(p)
    if p.suffix.lower() == ".twbx":
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            with zipfile.ZipFile(p) as z:
                _safe_extract(z, root, [])
            twbs = sorted(root.rglob("*.twb"))
            if not twbs:
                raise ValueError("TWBX does not contain a .twb workbook.")
            result = extract_twb(twbs[0])
            result["file"] = str(p)
            result["extensions"]["tableau"]["twbxFiles"] = [
                str(x.relative_to(root)).replace("\\", "/") for x in root.rglob("*") if x.is_file()
            ]
            return result
    raise ValueError("Tableau input must be TWB, TWBX, or a workbook folder.")

def to_bi_ir(workbook: dict, source: str) -> dict:
    return {
        "schema": "BI-X BI-IR", "schema_version": "1.0", "version": 1,
        "generated_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        "project": {"identity": {"name": workbook.get("name"), "platform": "Tableau"}},
        "source": {"platform": "Tableau", "format": Path(source).suffix.lower().lstrip("."), "input": source},
        "semantic_model": {
            "tables": [], "columns": [], "measures": [],
            "expressions": workbook.get("calculations", []),
            "parameters": workbook.get("parameters", []),
        },
        "report": {"worksheets": workbook.get("worksheets", []), "dashboards": workbook.get("dashboards", []),
                   "stories": workbook.get("stories", []), "filters": workbook.get("filters", []),
                   "actions": workbook.get("actions", [])},
        "extensions": {"tableau": workbook.get("extensions", {})},
        "lineage": {}, "validation": []
    }

def generate_twb(ir: dict, out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    twb = ir.get("extensions", {}).get("tableau", {}).get("rawXml")
    if twb:
        out.write_text(twb, encoding="utf-8")
        return out
    name = ir.get("project", {}).get("identity", {}).get("name", "BI-X Workbook")
    root = ET.Element("workbook", {"original-version": "unknown", "source-platform": "BI-X"})
    ET.SubElement(root, "repository-location", {"derived-from": "BI-X", "id": name})
    ET.ElementTree(root).write(out, encoding="utf-8", xml_declaration=True)
    return out

from __future__ import annotations
import re
from collections import defaultdict

class LineageService:
    def build(self, bi_ir: dict) -> dict:
        nodes, edges = [], []
        seen = set()
        def add_node(node_id, kind, name, **extra):
            if node_id in seen: return
            seen.add(node_id); nodes.append({"id": node_id, "type": kind, "name": name, **extra})
        sm = bi_ir.get("semantic_model") or {}
        for t in sm.get("tables", []):
            tid = f"table:{t.get('name')}"
            add_node(tid, "Table", t.get("name"))
            for c in t.get("columns", []):
                cid = f"{tid}:column:{c.get('name')}"
                add_node(cid, "Column", c.get("name"), parent=tid)
                edges.append({"source": tid, "target": cid, "type": "contains"})
            for m in t.get("measures", []):
                mid = f"{tid}:measure:{m.get('name')}"
                add_node(mid, "Measure", m.get("name"), parent=tid)
                edges.append({"source": tid, "target": mid, "type": "contains"})
                expr = m.get("expression") or ""
                for ref in re.findall(r"(?:'([^']+)'|([A-Za-z_][\w ]*))\s*\[\s*([^\]]+)\s*\]", expr):
                    table = ref[0] or ref[1]; col = ref[2]
                    target = f"table:{table}:column:{col}"
                    edges.append({"source": mid, "target": target, "type": "depends_on"})
        for r in sm.get("relationships", []):
            a=f"table:{r.get('fromTable')}:column:{r.get('fromColumn')}"
            b=f"table:{r.get('toTable')}:column:{r.get('toColumn')}"
            edges.append({"source": a, "target": b, "type": "relationship"})
        rep = bi_ir.get("report") or {}
        for v in rep.get("visuals", []):
            vid=f"visual:{v.get('pageId')}:{v.get('id')}"
            add_node(vid, "Visual", v.get("title") or v.get("type"), page=v.get("page"))
        return {"nodes": nodes, "edges": edges}

from __future__ import annotations
from pathlib import Path
import json, zipfile

class ValidationService:
    def validate_bi_ir(self, ir: dict) -> list[dict]:
        issues=[]
        if not ir.get("project"): issues.append({"check":"Project identity","status":"FAIL","details":"Missing project object"})
        if not ir.get("source", {}).get("platform"): issues.append({"check":"Source platform","status":"FAIL","details":"Missing source platform"})
        sm=ir.get("semantic_model") or {}
        tables={t.get("name") for t in sm.get("tables", [])}
        cols={(t.get("name"), c.get("name")) for t in sm.get("tables", []) for c in t.get("columns", [])}
        for r in sm.get("relationships", []):
            ok=(r.get("fromTable"),r.get("fromColumn")) in cols and (r.get("toTable"),r.get("toColumn")) in cols
            issues.append({"check":"Relationship endpoints","status":"PASS" if ok else "FAIL",
                            "details":f"{r.get('fromTable')}[{r.get('fromColumn')}] -> {r.get('toTable')}[{r.get('toColumn')}]"})
        issues.append({"check":"Semantic model","status":"PASS" if tables else "WARN",
                        "details":f"{len(tables)} tables"})
        return issues

    def validate_path(self, path: str | Path) -> list[dict]:
        p=Path(path)
        if not p.exists(): return [{"check":"Input exists","status":"FAIL","details":str(p)}]
        if p.is_file() and p.suffix.lower()==".zip":
            try:
                with zipfile.ZipFile(p) as z: bad=z.testzip()
                return [{"check":"ZIP integrity","status":"PASS" if bad is None else "FAIL","details":str(bad or "valid")}]
            except Exception as e:
                return [{"check":"ZIP integrity","status":"FAIL","details":str(e)}]
        return [{"check":"Input exists","status":"PASS","details":str(p.resolve())}]

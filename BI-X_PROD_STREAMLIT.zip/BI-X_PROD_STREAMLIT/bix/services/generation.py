from __future__ import annotations
import json, shutil, zipfile
from pathlib import Path
from ..adapters.tableau.adapter import generate_twb

class GenerationService:
    def generate(self, bi_ir: dict, target: str, output_dir: str | Path, mode="Best Effort") -> dict:
        out=Path(output_dir); out.mkdir(parents=True, exist_ok=True)
        if target=="Tableau":
            twb=generate_twb(bi_ir, out / f"{bi_ir.get('project',{}).get('identity',{}).get('name','generated')}.twb")
            z=out / f"{twb.stem}.twbx"
            with zipfile.ZipFile(z,"w",zipfile.ZIP_DEFLATED) as zz: zz.write(twb,twb.name)
            return {"folder":str(out),"files":[str(twb),str(z)],"mode":mode}
        if target=="Power BI":
            # Power BI generation is intentionally conservative: use the proven
            # rebuild artifact when present, and never fabricate unsupported PBIR/TMDL.
            ext=bi_ir.get("extensions",{}).get("powerbi",{})
            src=ext.get("rebuild")
            if src and Path(src).exists():
                return {"folder":str(src),"files":[str(src)],"mode":mode}
            return {"folder":str(out),"files":[],"mode":mode,
                    "warning":"No rebuild-ready Power BI source artifact is attached to this BI-IR. Use a Power BI extraction workspace and approved generator implementation."}
        raise ValueError(f"Unsupported target: {target}")

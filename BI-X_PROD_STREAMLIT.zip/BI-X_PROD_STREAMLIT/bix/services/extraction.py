from __future__ import annotations
import json, tempfile, shutil
from pathlib import Path
from ..adapters.powerbi import reference as pbi
from ..core.bir import normalize_powerbi
from ..adapters.tableau.adapter import extract as extract_tableau, to_bi_ir as tableau_to_bi_ir

class ExtractionService:
    def extract(self, source_platform: str, input_path: str | Path, output_dir: str | Path,
                include_raw: bool = True, full_culture: bool = False,
                generate_xlsx: bool = True, generate_markdown: bool = True,
                generate_rebuild: bool = True, progress=None) -> dict:
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)
        def step(msg):
            if progress: progress(msg)
        step("Detecting project")
        if source_platform == "Power BI":
            skipped = []
            with tempfile.TemporaryDirectory() as td:
                root = pbi.materialise(str(input_path), Path(td), skipped)
                proj = pbi.locate_project(root)
                step("Reading semantic model")
                model = pbi.load_model(proj["model_dir"], full_culture) if proj["model_dir"] else None
                pq, params = pbi.build_power_query(model) if model else ([], [])
                step("Reading report definition")
                report = pbi.load_report(proj["report_dir"], model, include_raw) if proj["report_dir"] else None
                meta = {
                    "tool": "BI-X Power BI adapter",
                    "input": str(input_path),
                    "project": {"name": proj["name"], "pbip": proj["pbip"].name if proj["pbip"] else None,
                                "pbipContent": pbi.load_json(proj["pbip"]) if proj["pbip"] else None,
                                "reportFolder": proj["report_dir"].name if proj["report_dir"] else None,
                                "modelFolder": proj["model_dir"].name if proj["model_dir"] else None,
                                "datasetReference": proj["dataset_ref"]},
                    "semanticModel": model, "powerQuery": pq, "parameters": params,
                    "report": report, "skippedCacheFiles": skipped
                }
                step("Validating")
                meta["validation"] = pbi.validate(proj, model, report, skipped)
                step("Building BI-IR")
                bir = normalize_powerbi(meta).to_dict()
                if generate_rebuild:
                    step("Creating rebuild artifact")
                    meta["rebuild"] = pbi.rebuild_project(proj, output)
            # write outside temporary source tree
            (output / "metadata.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
            (output / "bi-ir.json").write_text(json.dumps(bir, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
            if generate_xlsx:
                pbi.write_xlsx(meta, output / "metadata.xlsx")
            if generate_markdown:
                pbi.write_markdown(meta, output / "metadata.md")
            step("Complete")
            return {"metadata": meta, "bi_ir": bir, "output_dir": str(output)}
        if source_platform == "Tableau":
            step("Reading Tableau workbook")
            wb = extract_tableau(input_path)
            bir = tableau_to_bi_ir(wb, str(input_path))
            meta = {"tool": "BI-X Tableau adapter", "input": str(input_path), "workbook": wb,
                    "validation": [{"check": "TWB parsed", "status": "PASS", "details": "Secure XML parse completed."}]}
            (output / "metadata.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
            (output / "bi-ir.json").write_text(json.dumps(bir, indent=2, ensure_ascii=False), encoding="utf-8")
            if generate_markdown:
                lines = [f"# Tableau workbook - {wb.get('name')}", "", "## Summary",
                         f"- Worksheets: {len(wb.get('worksheets', []))}",
                         f"- Dashboards: {len(wb.get('dashboards', []))}",
                         f"- Fields: {len(wb.get('fields', []))}",
                         f"- Calculations: {len(wb.get('calculations', []))}"]
                (output / "metadata.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
            step("Complete")
            return {"metadata": meta, "bi_ir": bir, "output_dir": str(output)}
        raise ValueError(f"Unsupported platform: {source_platform}")

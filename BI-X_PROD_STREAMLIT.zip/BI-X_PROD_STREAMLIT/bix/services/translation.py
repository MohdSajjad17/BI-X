from __future__ import annotations
import json
from pathlib import Path
from ..ai.providers import provider_from_env

class TranslationService:
    def __init__(self, history_path=None):
        self.history_path=Path(history_path or "workspace/translation_history.jsonl")
        self.history_path.parent.mkdir(parents=True,exist_ok=True)
    def translate(self, provider, model, source_language, target_language, expression, context=None, api_key=None, endpoint=None):
        p=provider_from_env(provider,api_key,endpoint)
        result=p.translate(source_language=source_language,target_language=target_language,expression=expression,context=context,model=model)
        with self.history_path.open("a",encoding="utf-8") as f:
            f.write(json.dumps(result.to_dict(),ensure_ascii=False)+"\n")
        return result.to_dict()
    def history(self):
        if not self.history_path.exists(): return []
        return [json.loads(x) for x in self.history_path.read_text(encoding="utf-8").splitlines() if x.strip()]

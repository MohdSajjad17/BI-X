from __future__ import annotations
import json, shutil, uuid
from pathlib import Path
from datetime import datetime, timezone

class WorkspaceService:
    def __init__(self, root="workspace"):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def create(self,name):
        slug="".join(c if c.isalnum() or c in "-_" else "_" for c in name).strip("_") or "project"
        p=self.root/f"{slug}_{uuid.uuid4().hex[:8]}"
        for d in ["source","bi-ir","metadata","lineage","validation","generated","comparisons"]:
            (p/d).mkdir(parents=True,exist_ok=True)
        (p/"manifest.json").write_text(json.dumps({"workspace_id":p.name,"created_at":datetime.now(timezone.utc).isoformat(),"name":name},indent=2),encoding="utf-8")
        return p
